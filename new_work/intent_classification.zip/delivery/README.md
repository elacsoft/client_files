###Introduction

The script reads intent data from files and then can be used to check other comments for intent.

# Setting
- Put data files in data/ directory, add their names in line 99 of intent.py and call the function to fetch data for each file (as already done line 101-107)

- Run the script, it will prompt to enter a comment, it will return "INTENT" or "NO"

- In order to test multiple comments thorugh a file, put the test file in same directory as code, comment line 110-111, uncomment 114-119. Remove or add test files as in 115-117. (NOTE: all language files must be kept separate and in case of arabic, a second optional argument must be sent o check_intent method)

###End